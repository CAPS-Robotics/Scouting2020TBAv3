
# EventOPRs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**oprs** | **Map&lt;String, Float&gt;** | A key-value pair with team key (eg &#x60;frc254&#x60;) as key and OPR as value. |  [optional]
**dprs** | **Map&lt;String, Float&gt;** | A key-value pair with team key (eg &#x60;frc254&#x60;) as key and DPR as value. |  [optional]
**ccwms** | **Map&lt;String, Float&gt;** | A key-value pair with team key (eg &#x60;frc254&#x60;) as key and CCWM as value. |  [optional]



