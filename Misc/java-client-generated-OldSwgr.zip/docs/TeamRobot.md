
# TeamRobot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**year** | **Integer** | Year this robot competed in. | 
**robotName** | **String** | Name of the robot as provided by the team. | 
**key** | **String** | Internal TBA identifier for this robot. | 
**teamKey** | **String** | TBA team key for this robot. | 



