
# EliminationAllianceBackup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**out** | **String** | Team key that was replaced by the backup team. |  [optional]
**in** | **String** | Team key that was called in as the backup. |  [optional]



