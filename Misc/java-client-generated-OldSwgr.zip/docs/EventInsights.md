
# EventInsights

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**qual** | **Object** | Inights for the qualification round of an event |  [optional]
**playoff** | **Object** | Insights for the playoff round of an event |  [optional]



