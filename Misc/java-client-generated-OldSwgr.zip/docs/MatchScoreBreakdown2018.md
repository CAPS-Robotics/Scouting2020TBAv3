
# MatchScoreBreakdown2018

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**blue** | [**MatchScoreBreakdown2018Alliance**](MatchScoreBreakdown2018Alliance.md) |  |  [optional]
**red** | [**MatchScoreBreakdown2018Alliance**](MatchScoreBreakdown2018Alliance.md) |  |  [optional]



