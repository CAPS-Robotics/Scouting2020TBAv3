
# TeamEventStatusRankSortOrderInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | The descriptive name of the value used to sort the ranking. |  [optional]
**precision** | **Integer** | The number of digits of precision used for this value, eg &#x60;2&#x60; would correspond to a value of &#x60;101.11&#x60; while &#x60;0&#x60; would correspond to &#x60;101&#x60;. |  [optional]



