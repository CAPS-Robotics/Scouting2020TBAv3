
# TeamEventStatusAllianceBackup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**out** | **String** | TBA key for the team replaced by the backup. |  [optional]
**in** | **String** | TBA key for the backup team called in. |  [optional]



