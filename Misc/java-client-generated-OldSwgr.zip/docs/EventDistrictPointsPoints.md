
# EventDistrictPointsPoints

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alliancePoints** | **Integer** | Points awarded for alliance selection | 
**awardPoints** | **Integer** | Points awarded for event awards. | 
**qualPoints** | **Integer** | Points awarded for qualification match performance. | 
**elimPoints** | **Integer** | Points awarded for elimination match performance. | 
**total** | **Integer** | Total points awarded at this event. | 



