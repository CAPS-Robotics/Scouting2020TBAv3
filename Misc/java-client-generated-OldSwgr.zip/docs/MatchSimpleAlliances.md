
# MatchSimpleAlliances

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**blue** | [**MatchAlliance**](MatchAlliance.md) |  |  [optional]
**red** | [**MatchAlliance**](MatchAlliance.md) |  |  [optional]



