
# MatchVideos

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** | Unique key representing this video |  [optional]
**type** | **String** | Can be one of &#39;youtube&#39; or &#39;tba&#39; |  [optional]



