
# EventDistrictPointsTiebreakers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**highestQualScores** | **List&lt;Integer&gt;** |  |  [optional]
**qualWins** | **Integer** |  |  [optional]



