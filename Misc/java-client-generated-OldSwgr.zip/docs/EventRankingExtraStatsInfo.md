
# EventRankingExtraStatsInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the field used in the &#x60;extra_stats&#x60; array. | 
**precision** | [**BigDecimal**](BigDecimal.md) | Integer expressing the number of digits of precision in the number provided in &#x60;sort_orders&#x60;. | 



