
# EliminationAllianceStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentLevelRecord** | [**WLTRecord**](WLTRecord.md) |  |  [optional]
**level** | **String** |  |  [optional]
**playoffAverage** | **Double** |  |  [optional]
**record** | [**WLTRecord**](WLTRecord.md) |  |  [optional]
**status** | **String** |  |  [optional]



