
# TeamEventStatusRank

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numTeams** | **Integer** | Number of teams ranked. |  [optional]
**ranking** | [**TeamEventStatusRankRanking**](TeamEventStatusRankRanking.md) |  |  [optional]
**sortOrderInfo** | [**List&lt;TeamEventStatusRankSortOrderInfo&gt;**](TeamEventStatusRankSortOrderInfo.md) | Ordered list of names corresponding to the elements of the &#x60;sort_orders&#x60; array. |  [optional]
**status** | **String** |  |  [optional]



