# EventDistrictPointsPoints

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **Integer** | Total points awarded at this event. | 
**alliancePoints** | **Integer** | Points awarded for alliance selection | 
**elimPoints** | **Integer** | Points awarded for elimination match performance. | 
**awardPoints** | **Integer** | Points awarded for event awards. | 
**qualPoints** | **Integer** | Points awarded for qualification match performance. | 
