# MatchScoreBreakdown2017

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**blue** | [**MatchScoreBreakdown2017Alliance**](MatchScoreBreakdown2017Alliance.md) |  |  [optional]
**red** | [**MatchScoreBreakdown2017Alliance**](MatchScoreBreakdown2017Alliance.md) |  |  [optional]
