# MatchScoreBreakdown2020

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**blue** | [**MatchScoreBreakdown2020Alliance**](MatchScoreBreakdown2020Alliance.md) |  |  [optional]
**red** | [**MatchScoreBreakdown2020Alliance**](MatchScoreBreakdown2020Alliance.md) |  |  [optional]
