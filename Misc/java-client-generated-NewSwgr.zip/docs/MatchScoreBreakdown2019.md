# MatchScoreBreakdown2019

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**blue** | [**MatchScoreBreakdown2019Alliance**](MatchScoreBreakdown2019Alliance.md) |  |  [optional]
**red** | [**MatchScoreBreakdown2019Alliance**](MatchScoreBreakdown2019Alliance.md) |  |  [optional]
