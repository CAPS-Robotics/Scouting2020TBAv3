# APIStatusAppVersion

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**minAppVersion** | **Integer** | Internal use - Minimum application version required to correctly connect and process data. | 
**latestAppVersion** | **Integer** | Internal use - Latest application version available. | 
