# MatchScoreBreakdown2016

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**blue** | [**MatchScoreBreakdown2016Alliance**](MatchScoreBreakdown2016Alliance.md) |  |  [optional]
**red** | [**MatchScoreBreakdown2016Alliance**](MatchScoreBreakdown2016Alliance.md) |  |  [optional]
