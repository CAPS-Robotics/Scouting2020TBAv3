# AwardRecipient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**teamKey** | **String** | The TBA team key for the team that was given the award. May be null. |  [optional]
**awardee** | **String** | The name of the individual given the award. May be null. |  [optional]
