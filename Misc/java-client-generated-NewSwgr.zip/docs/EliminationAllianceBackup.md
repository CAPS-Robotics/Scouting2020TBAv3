# EliminationAllianceBackup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**in** | **String** | Team key that was called in as the backup. |  [optional]
**out** | **String** | Team key that was replaced by the backup team. |  [optional]
