# TeamEventStatusAlliance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Alliance name, may be null. |  [optional]
**number** | **Integer** | Alliance number. | 
**backup** | [**TeamEventStatusAllianceBackup**](TeamEventStatusAllianceBackup.md) |  |  [optional]
**pick** | **Integer** | Order the team was picked in the alliance from 0-2, with 0 being alliance captain. | 
