# MatchVideos

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | Can be one of &#x27;youtube&#x27; or &#x27;tba&#x27; |  [optional]
**key** | **String** | Unique key representing this video |  [optional]
