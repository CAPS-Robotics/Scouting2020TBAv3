# WLTRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**losses** | **Integer** | Number of losses. | 
**wins** | **Integer** | Number of wins. | 
**ties** | **Integer** | Number of ties. | 
