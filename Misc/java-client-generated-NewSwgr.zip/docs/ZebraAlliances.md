# ZebraAlliances

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**red** | [**List&lt;ZebraTeam&gt;**](ZebraTeam.md) | Zebra MotionWorks data for teams on the red alliance |  [optional]
**blue** | [**List&lt;ZebraTeam&gt;**](ZebraTeam.md) | Zebra data for teams on the blue alliance |  [optional]
