# MatchScoreBreakdown2015

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**blue** | [**MatchScoreBreakdown2015Alliance**](MatchScoreBreakdown2015Alliance.md) |  |  [optional]
**red** | [**MatchScoreBreakdown2015Alliance**](MatchScoreBreakdown2015Alliance.md) |  |  [optional]
**coopertition** | [**CoopertitionEnum**](#CoopertitionEnum) |  |  [optional]
**coopertitionPoints** | **Integer** |  |  [optional]

<a name="CoopertitionEnum"></a>
## Enum: CoopertitionEnum
Name | Value
---- | -----
NONE | &quot;None&quot;
UNKNOWN | &quot;Unknown&quot;
STACK | &quot;Stack&quot;
