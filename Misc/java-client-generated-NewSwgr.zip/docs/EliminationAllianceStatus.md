# EliminationAllianceStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**playoffAverage** | **Double** |  |  [optional]
**level** | **String** |  |  [optional]
**record** | [**WLTRecord**](WLTRecord.md) |  |  [optional]
**currentLevelRecord** | [**WLTRecord**](WLTRecord.md) |  |  [optional]
**status** | **String** |  |  [optional]
