# EventPredictions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
