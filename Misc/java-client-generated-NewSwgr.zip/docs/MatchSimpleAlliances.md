# MatchSimpleAlliances

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**red** | [**MatchAlliance**](MatchAlliance.md) |  |  [optional]
**blue** | [**MatchAlliance**](MatchAlliance.md) |  |  [optional]
