package com.thebluealliance.api.v3.models;

import lombok.Value;

@Value
public class ScoreBreakdown {

	MatchScoreBreakdown2020Alliance blue;
	MatchScoreBreakdown2020Alliance red;
}
