/**
 * Contains the models represented by JSON data from The Blue Alliance API.
 *
 * @see com.thebluealliance.api.v3.Deserializer
 */
package com.thebluealliance.api.v3.models;
