/**
 * Provides the classes necessary to access The Blue Alliance API and deserialize JSON data obtained from the API into object models
 */
package com.thebluealliance.api.v3;